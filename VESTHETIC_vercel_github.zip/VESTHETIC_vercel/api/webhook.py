import json, os, urllib.request, urllib.parse

BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_IDS = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()}
MANAGER_USERNAME = os.getenv("MANAGER_USERNAME", "VESTHETIC_manager")

TEXTS = {
"ru": {"choose":"Выберите язык:","welcome":"💎 VESTHETIC | Digital Talent Agency\n\nМы работаем с совершеннолетними онлайн-креаторами по всему миру.\n\nВыберите действие:","about":"VESTHETIC помогает 18+ креаторам запускаться и развиваться на международных платформах. Работа добровольная, удалённая и с гибким графиком.","terms":"💰 Условия\n\nCreator: 75%\nVESTHETIC: 25%\n\nТочные выплаты зависят от платформы и условий сотрудничества.","faq":"❓ FAQ\n\n18+ обязательно. Опыт не обязателен. Можно работать из дома и выбирать график. Не отправляйте сюда паспорт, банковские данные или интимные материалы.","apply":"📝 Начинаем короткую заявку. Пожалуйста, отвечайте по одному вопросу.","name":"Как вас зовут или какой псевдоним использовать?","age":"Подтверждаете, что вам 18 лет или больше?","country":"В какой стране вы сейчас находитесь?","languages":"Какие языки вы знаете?","experience":"Есть ли опыт работы онлайн-креатором/моделью?","equipment":"Какое оборудование у вас есть?","schedule":"Какой график вам удобен?","contact":"Ваш Telegram username для связи с менеджером (например @username):","source":"Где вы узнали о VESTHETIC?","done":"✅ Заявка получена. Менеджер VESTHETIC свяжется с вами после рассмотрения.","noage":"Для сотрудничества VESTHETIC требуется возраст 18+.","manager":"👩‍💼 Менеджер: @{u}","cancel":"Заявка отменена. Вы вернулись в главное меню."},
"en": {"choose":"Choose your language:","welcome":"💎 VESTHETIC | Digital Talent Agency\n\nWe work with adult 18+ online creators worldwide.\n\nChoose an action:","about":"VESTHETIC helps adult creators launch and grow on international platforms. Cooperation is voluntary, remote and flexible.","terms":"💰 Terms\n\nCreator: 75%\nVESTHETIC: 25%\n\nExact payouts depend on the platform and cooperation terms.","faq":"❓ FAQ\n\n18+ required. No experience required. Remote and flexible schedule. Do not send passports, bank details or intimate material here.","apply":"📝 Let's start a short application. Please answer one question at a time.","name":"What is your name or preferred stage name?","age":"Do you confirm that you are 18 or older?","country":"Which country are you currently in?","languages":"Which languages do you speak?","experience":"Do you have experience as an online creator/model?","equipment":"What equipment do you have?","schedule":"What schedule works for you?","contact":"Your Telegram username for the manager (e.g. @username):","source":"How did you hear about VESTHETIC?","done":"✅ Application received. A VESTHETIC manager will contact you after review.","noage":"VESTHETIC cooperation requires you to be 18+.","manager":"👩‍💼 Manager: @{u}","cancel":"Application cancelled. Back to the main menu."},
"sk": {"choose":"Vyberte jazyk:","welcome":"💎 VESTHETIC | Digital Talent Agency\n\nSpolupracujeme s dospelými online tvorcami 18+ z celého sveta.\n\nVyberte akciu:","about":"VESTHETIC pomáha dospelým tvorcom začať a rozvíjať sa na medzinárodných platformách. Spolupráca je dobrovoľná, na diaľku a flexibilná.","terms":"💰 Podmienky\n\nTvorca: 75 %\nVESTHETIC: 25 %\n\nPresná výplata závisí od platformy a dohody.","faq":"❓ FAQ\n\nVyžaduje sa vek 18+. Skúsenosti nie sú potrebné. Práca na diaľku a flexibilný čas. Neposielajte sem pas, bankové údaje ani intímny materiál.","apply":"📝 Začnime krátku žiadosť. Odpovedajte prosím po jednej otázke.","name":"Ako sa voláte alebo aký pseudonym chcete používať?","age":"Potvrdzujete, že máte 18 rokov alebo viac?","country":"V ktorej krajine sa momentálne nachádzate?","languages":"Akými jazykmi hovoríte?","experience":"Máte skúsenosti ako online tvorca/model?","equipment":"Aké vybavenie máte?","schedule":"Aký pracovný čas vám vyhovuje?","contact":"Váš Telegram username pre manažéra (napr. @username):","source":"Ako ste sa dozvedeli o VESTHETIC?","done":"✅ Žiadosť bola prijatá. Manažér VESTHETIC vás bude kontaktovať po posúdení.","noage":"Pre spoluprácu s VESTHETIC je potrebný vek 18+.","manager":"👩‍💼 Manažér: @{u}","cancel":"Žiadosť zrušená. Späť do hlavného menu."},
"ua": {"choose":"Оберіть мову:","welcome":"💎 VESTHETIC | Digital Talent Agency\n\nМи працюємо з повнолітніми онлайн-креаторами 18+ з усього світу.\n\nОберіть дію:","about":"VESTHETIC допомагає повнолітнім креаторам запускатися та розвиватися на міжнародних платформах. Співпраця добровільна, дистанційна та гнучка.","terms":"💰 Умови\n\nКреатор: 75 %\nVESTHETIC: 25 %\n\nТочні виплати залежать від платформи та умов співпраці.","faq":"❓ FAQ\n\n18+ обов'язково. Досвід не потрібен. Дистанційна робота та гнучкий графік. Не надсилайте сюди паспорт, банківські дані чи інтимні матеріали.","apply":"📝 Почнемо коротку заявку. Будь ласка, відповідайте на одне питання за раз.","name":"Як вас звати або який псевдонім використовувати?","age":"Підтверджуєте, що вам 18 років або більше?","country":"У якій країні ви зараз перебуваєте?","languages":"Якими мовами ви володієте?","experience":"Чи маєте досвід онлайн-креатора/моделі?","equipment":"Яке обладнання у вас є?","schedule":"Який графік вам зручний?","contact":"Ваш Telegram username для менеджера (наприклад @username):","source":"Де ви дізналися про VESTHETIC?","done":"✅ Заявку отримано. Менеджер VESTHETIC зв'яжеться з вами після розгляду.","noage":"Для співпраці з VESTHETIC потрібен вік 18+.","manager":"👩‍💼 Менеджер: @{u}","cancel":"Заявку скасовано. Ви повернулися до головного меню."}}

states = {}

def tg(method, data):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(f"https://api.telegram.org/bot{BOT_TOKEN}/{method}", data=body)
    with urllib.request.urlopen(req, timeout=10) as r: return json.loads(r.read())

def send(chat_id, text, keyboard=None):
    d={"chat_id":chat_id,"text":text}
    if keyboard: d["reply_markup"]=json.dumps(keyboard,ensure_ascii=False)
    return tg("sendMessage",d)

def lang_keyboard():
    return {"inline_keyboard":[[{"text":"🇷🇺 Русский","callback_data":"lang:ru"},{"text":"🇺🇦 Українська","callback_data":"lang:ua"}],[{"text":"🇸🇰 Slovenčina","callback_data":"lang:sk"},{"text":"🇬🇧 English","callback_data":"lang:en"}]]}

def menu():
    return {"inline_keyboard":[[{"text":"💎 About VESTHETIC","callback_data":"menu:about"},{"text":"💰 Terms","callback_data":"menu:terms"}],[{"text":"❓ FAQ","callback_data":"menu:faq"},{"text":"📝 Apply","callback_data":"apply"}],[{"text":"👩‍💼 Manager","callback_data":"manager"},{"text":"🌐 Language","callback_data":"language"}]]}

def handle(update):
    if "callback_query" in update:
        q=update["callback_query"]; cid=q["message"]["chat"]["id"]; data=q["data"]; tg("answerCallbackQuery",{"callback_query_id":q["id"]})
        if data.startswith("lang:"):
            l=data.split(":")[1]; states.setdefault(cid,{})["lang"]=l; send(cid,TEXTS[l]["welcome"],menu()); return
        l=states.get(cid,{}).get("lang","ru"); t=TEXTS[l]
        if data=="language": send(cid,t["choose"],lang_keyboard())
        elif data=="menu:about": send(cid,t["about"],menu())
        elif data=="menu:terms": send(cid,t["terms"],menu())
        elif data=="menu:faq": send(cid,t["faq"],menu())
        elif data=="manager": send(cid,t["manager"].format(u=MANAGER_USERNAME),menu())
        elif data=="apply": states[cid]={"lang":l,"step":"name","answers":{}}; send(cid,t["apply"]+"\n\n"+t["name"])
        return
    msg=update.get("message",{}); cid=msg.get("chat",{}).get("id"); text=msg.get("text","").strip()
    if not cid:return
    if text=="/start":
        if states.get(cid,{}).get("lang"): l=states[cid]["lang"]; send(cid,TEXTS[l]["welcome"],menu())
        else: send(cid,TEXTS["ru"]["choose"],lang_keyboard())
        return
    if text=="/cancel":
        l=states.get(cid,{}).get("lang","ru"); states[cid]={"lang":l}; send(cid,TEXTS[l]["cancel"],menu()); return
    s=states.get(cid)
    if not s or "step" not in s: send(cid,TEXTS["ru"]["choose"],lang_keyboard()); return
    l=s["lang"]; t=TEXTS[l]; step=s["step"]; s["answers"][step]=text
    order=["name","age","country","languages","experience","equipment","schedule","contact","source"]
    if step=="age" and text.lower() not in ("yes","да","так","ano","si","18"):
        send(cid,t["noage"]); s["answers"].pop("age",None); return
    i=order.index(step)
    if i+1<len(order): s["step"]=order[i+1]; send(cid,t[order[i+1]])
    else:
        a=s["answers"]; s.pop("step",None); summary="\n".join(f"{k}: {v}" for k,v in a.items()); uname=msg.get("from",{}).get("username","")
        for aid in ADMIN_IDS: send(aid,f"🆕 VESTHETIC application\nTelegram ID: {cid}\nUsername: @{uname}\n\n{summary}")
        send(cid,t["done"],menu())

def handler(request):
    if request.method=="GET": return {"ok":True,"service":"VESTHETIC"}
    try: handle(request.get_json(silent=True) or {})
    except Exception as e: print("Webhook error",repr(e))
    return {"ok":True}
